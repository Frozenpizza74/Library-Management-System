-- Create the Book table
CREATE TABLE Book (
    BookID INT PRIMARY KEY,
    Keyword VARCHAR(255),
    Title VARCHAR(255),
    YearPub INT,
    CopiesAv INT,
    BScore DECIMAL(3, 2),
    Trsc_ID INT,
    Author_ID INT,
    Pub_ID INT,
    FOREIGN KEY (Author_ID) REFERENCES Author(Author_ID),
    FOREIGN KEY (Pub_ID) REFERENCES Publisher(Pub_ID)
);

INSERT INTO Book (BookID, Keyword, Title, YearPub, CopiesAv, BScore, Trsc_ID, Author_ID, Pub_ID) VALUES
(1, 'Fiction', 'The Great Adventure', 2020, 5, 4.5, 1001, 1, 1),
(2, 'Science', 'Physics Fundamentals', 2018, 10, 4.8, 1002, 2, 2),
(3, 'Technology', 'AI and Future', 2022, 7, 4.9, 1003, 3, 3),
(4, 'History', 'World Wars Overview', 2015, 3, 4.3, 1004, 4, 4),
(5, 'Biography', 'Life of Einstein', 2019, 8, 4.7, 1005, 5, 5),
(6, 'Fiction', 'Mystery of the Night', 2021, 6, 4.6, 1006, 1, 6),
(7, 'Health', 'Healthy Living Guide', 2017, 12, 4.2, 1007, 6, 2),
(8, 'Finance', 'Smart Investing', 2020, 9, 4.4, 1008, 7, 7),
(9, 'Education', 'Learning Strategies', 2016, 11, 4.1, 1009, 8, 8),
(10, 'Self-Help', 'Mindset Matters', 2023, 15, 4.9, 1010, 9, 9);


-- Create the Member table
CREATE TABLE Member (
    Mem_ID INT PRIMARY KEY,
    Fname VARCHAR(50),
    Lname VARCHAR(50),
    Address VARCHAR(255),
    Phone VARCHAR(20),
    Email VARCHAR(100),
    BorrowHs INT,
    Book_ID INT,
    FOREIGN KEY (Book_ID) REFERENCES Book(BookID)
);


INSERT INTO Member (Mem_ID, Fname, Lname, Address, Phone, Email, BorrowHs, Book_ID) VALUES
(1, 'John', 'Doe', '123 Elm Street', '123-456-7890', 'john.doe@example.com', 5, 1),
(2, 'Jane', 'Smith', '456 Oak Avenue', '987-654-3210', 'jane.smith@example.com', 3, 2),
(3, 'Alice', 'Johnson', '789 Pine Lane', '555-555-5555', 'alice.johnson@example.com', 7, 3),
(4, 'Bob', 'Brown', '321 Maple Drive', '444-444-4444', 'bob.brown@example.com', 2, 4),
(5, 'Charlie', 'Davis', '654 Cedar Road', '333-333-3333', 'charlie.davis@example.com', 4, 5),
(6, 'Emily', 'White', '987 Birch Blvd', '222-222-2222', 'emily.white@example.com', 6, 6),
(7, 'Frank', 'Harris', '159 Walnut St', '111-111-1111', 'frank.harris@example.com', 1, 7),
(8, 'Grace', 'Clark', '753 Aspen Circle', '777-777-7777', 'grace.clark@example.com', 5, 8),
(9, 'Henry', 'Martinez', '258 Willow Way', '888-888-8888', 'henry.martinez@example.com', 8, 9),
(10, 'Isabella', 'Taylor', '147 Fir Lane', '999-999-9999', 'isabella.taylor@example.com', 10, 10);



-- Create the Member/Book table (junction table)
CREATE TABLE Member_Book (
    Mem_ID INT,
    Book_ID INT,
    Phone VARCHAR(20),
    Email VARCHAR(100),
    PRIMARY KEY (Mem_ID, Book_ID),
    FOREIGN KEY (Mem_ID) REFERENCES Member(Mem_ID),
    FOREIGN KEY (Book_ID) REFERENCES Book(BookID)
);

INSERT INTO Member_Book (Mem_ID, Book_ID, Phone, Email) VALUES
(1, 1, '123-456-7890', 'john.doe@example.com'),
(2, 2, '987-654-3210', 'jane.smith@example.com'),
(3, 3, '555-555-5555', 'alice.johnson@example.com'),
(4, 4, '444-444-4444', 'bob.brown@example.com'),
(5, 5, '333-333-3333', 'charlie.davis@example.com'),
(6, 6, '222-222-2222', 'emily.white@example.com'),
(7, 7, '111-111-1111', 'frank.harris@example.com'),
(8, 8, '777-777-7777', 'grace.clark@example.com'),
(9, 9, '888-888-8888', 'henry.martinez@example.com'),
(10, 10, '999-999-9999', 'isabella.taylor@example.com');


-- Create the Branch table
CREATE TABLE Branch (
    Bran_ID INT PRIMARY KEY,
    Location VARCHAR(255),
    Phone VARCHAR(20),
    Email VARCHAR(100),
    Book_ID INT,
    FOREIGN KEY (Book_ID) REFERENCES Book(BookID)
);


INSERT INTO Branch (Bran_ID, Location, Phone, Email, Book_ID) VALUES
(1, 'Downtown Library', '123-111-2222', 'downtown.library@example.com', 1),
(2, 'Eastside Branch', '123-222-3333', 'eastside.branch@example.com', 2),
(3, 'Westside Branch', '123-333-4444', 'westside.branch@example.com', 3),
(4, 'Northside Branch', '123-444-5555', 'northside.branch@example.com', 4),
(5, 'Southside Branch', '123-555-6666', 'southside.branch@example.com', 5),
(6, 'Midtown Library', '123-666-7777', 'midtown.library@example.com', 6),
(7, 'Uptown Branch', '123-777-8888', 'uptown.branch@example.com', 7),
(8, 'Central Library', '123-888-9999', 'central.library@example.com', 8),
(9, 'Hilltop Branch', '123-999-0000', 'hilltop.branch@example.com', 9),
(10, 'Lakeside Library', '123-000-1111', 'lakeside.library@example.com', 10);

-- Create the Category table
CREATE TABLE Category (
    Cat_ID INT PRIMARY KEY,
    Type VARCHAR(100),
    Desc VARCHAR(255),
    BorrowC INT
);

-- Create the Category table
CREATE TABLE Category (
    Cat_ID INT PRIMARY KEY,
    Type VARCHAR(100),
    Desc VARCHAR(255),
    BorrowC INT
);

-- Insert 10 records into the Category table
INSERT INTO Category (Cat_ID, Type, Desc, BorrowC) VALUES
(1, 'Fiction', 'Books with imaginative narratives or stories', 20),
(2, 'Science', 'Books focused on scientific knowledge and research', 15),
(3, 'Technology', 'Books about technological advancements and applications', 18),
(4, 'History', 'Books covering historical events and analyses', 12),
(5, 'Biography', 'Books detailing the lives of notable individuals', 10),
(6, 'Health', 'Books providing information on health and wellness', 25),
(7, 'Finance', 'Books on managing money and financial systems', 8),
(8, 'Education', 'Books about learning techniques and systems', 22),
(9, 'Self-Help', 'Books aimed at personal development', 30),
(10, 'Adventure', 'Books with exciting and risky storylines', 17);

-- Create the Book/Category table (junction table)
CREATE TABLE Book_Category (
    Cat_ID INT,
    Book_ID INT,
    PRIMARY KEY (Cat_ID, Book_ID),
    FOREIGN KEY (Cat_ID) REFERENCES Category(Cat_ID),
    FOREIGN KEY (Book_ID) REFERENCES Book(BookID)
);
INSERT INTO Book_Category (Cat_ID, Book_ID) VALUES
(1, 1),  -- Fiction, The Great Adventure
(2, 2),  -- Science, Physics Fundamentals
(3, 3),  -- Technology, AI and Future
(4, 4),  -- History, World Wars Overview
(5, 5),  -- Biography, Life of Einstein
(1, 6),  -- Fiction, Mystery of the Night
(6, 7),  -- Health, Healthy Living Guide
(7, 8),  -- Finance, Smart Investing
(8, 9),  -- Education, Learning Strategies
(9, 10); -- Self-Help, Mindset Matters


-- Create the Staff table
CREATE TABLE Staff (
    Staff_ID INT PRIMARY KEY,
    Name VARCHAR(100),
    Phone VARCHAR(20),
    Email VARCHAR(100),
    Position VARCHAR(50),
    HireDate DATE
);


INSERT INTO Staff (Staff_ID, Name, Phone, Email, Position, HireDate) VALUES
(1, 'Alice Johnson', '123-111-2222', 'alice.johnson@example.com', 'Librarian', '2020-01-15'),
(2, 'Bob Smith', '123-222-3333', 'bob.smith@example.com', 'Assistant Librarian', '2018-06-10'),
(3, 'Carol Brown', '123-333-4444', 'carol.brown@example.com', 'IT Specialist', '2019-09-01'),
(4, 'David Wilson', '123-444-5555', 'david.wilson@example.com', 'Branch Manager', '2017-03-20'),
(5, 'Emma Davis', '123-555-6666', 'emma.davis@example.com', 'Customer Service Rep', '2021-05-25'),
(6, 'Frank Harris', '123-666-7777', 'frank.harris@example.com', 'Accountant', '2016-11-30'),
(7, 'Grace Clark', '123-777-8888', 'grace.clark@example.com', 'Inventory Manager', '2019-08-15'),
(8, 'Henry Martinez', '123-888-9999', 'henry.martinez@example.com', 'Archivist', '2020-12-01'),
(9, 'Isabella Taylor', '123-999-0000', 'isabella.taylor@example.com', 'Technical Assistant', '2022-07-10'),
(10, 'Jack White', '123-000-1111', 'jack.white@example.com', 'Maintenance Staff', '2015-04-05');

-- Create the Staff/Branch table (junction table)
CREATE TABLE Staff_Branch (
    Staff_ID INT,
    Bran_ID INT,
    PRIMARY KEY (Staff_ID, Bran_ID),
    FOREIGN KEY (Staff_ID) REFERENCES Staff(Staff_ID),
    FOREIGN KEY (Bran_ID) REFERENCES Branch(Bran_ID)
);

INSERT INTO Staff_Branch (Staff_ID, Bran_ID) VALUES
(1, 1),  -- Alice Johnson at Branch 1
(2, 1),  -- Bob Smith at Branch 1
(3, 2),  -- Carol Brown at Branch 2
(4, 2),  -- David Wilson at Branch 2
(5, 3),  -- Emma Davis at Branch 3
(6, 1),  -- Frank Harris at Branch 1
(7, 3),  -- Grace Clark at Branch 3
(8, 2),  -- Henry Martinez at Branch 2
(9, 3),  -- Isabella Taylor at Branch 3
(10, 1); -- Jack White at Branch 1


-- Create the Transaction table
CREATE TABLE Transaction (
    Trsc_ID INT PRIMARY KEY,
    BorrowD DATE,
    DueDate DATE,
    ReturnD DATE,
    Mem_ID INT,
    Book_ID INT,
    FOREIGN KEY (Mem_ID) REFERENCES Member(Mem_ID),
    FOREIGN KEY (Book_ID) REFERENCES Book(BookID)
);

INSERT INTO Transaction (Trsc_ID, BorrowD, DueDate, ReturnD, Mem_ID, Book_ID) VALUES
(1, '2024-01-05', '2024-01-20', '2024-01-18', 1, 1),
(2, '2024-02-10', '2024-02-25', '2024-02-22', 2, 2),
(3, '2024-03-15', '2024-03-30', '2024-03-28', 3, 3),
(4, '2024-04-01', '2024-04-16', NULL, 4, 4),
(5, '2024-05-10', '2024-05-25', '2024-05-23', 5, 5),
(6, '2024-06-20', '2024-07-05', NULL, 6, 6),
(7, '2024-07-15', '2024-07-30', '2024-07-29', 7, 7),
(8, '2024-08-01', '2024-08-16', '2024-08-14', 8, 8),
(9, '2024-09-10', '2024-09-25', '2024-09-22', 9, 9),
(10, '2024-10-05', '2024-10-20', NULL, 10, 10);



-- Create the Author table
CREATE TABLE Author (
    Author_ID INT PRIMARY KEY,
    Name VARCHAR(100),
    BirthDate DATE,
    Email VARCHAR(100),
    Phone VARCHAR(20),
    Address VARCHAR(255),
    Book_ID INT,
    FOREIGN KEY (Book_ID) REFERENCES Book(BookID)
);

INSERT INTO Author (Author_ID, Name, BirthDate, Email, Phone, Address, Book_ID) VALUES
(1, 'John Green', '1977-08-24', 'john.green@example.com', '123-111-2222', '123 Elm Street, New York', 1),
(2, 'Jane Austen', '1775-12-16', 'jane.austen@example.com', '123-222-3333', '456 Oak Avenue, London', 2),
(3, 'Isaac Asimov', '1920-01-02', 'isaac.asimov@example.com', '123-333-4444', '789 Pine Lane, Boston', 3),
(4, 'George Orwell', '1903-06-25', 'george.orwell@example.com', '123-444-5555', '321 Maple Drive, Paris', 4),
(5, 'Albert Einstein', '1879-03-14', 'albert.einstein@example.com', '123-555-6666', '654 Cedar Road, Zurich', 5),
(6, 'Stephen King', '1947-09-21', 'stephen.king@example.com', '123-666-7777', '987 Birch Blvd, Maine', 6),
(7, 'J.K. Rowling', '1965-07-31', 'jk.rowling@example.com', '123-777-8888', '159 Walnut St, Edinburgh', 7),
(8, 'Mark Twain', '1835-11-30', 'mark.twain@example.com', '123-888-9999', '753 Aspen Circle, Missouri', 8),
(9, 'Harper Lee', '1926-04-28', 'harper.lee@example.com', '123-999-0000', '258 Willow Way, Monroeville', 9),
(10, 'F. Scott Fitzgerald', '1896-09-24', 'f.scott.fitzgerald@example.com', '123-000-1111', '147 Fir Lane, New York', 10);

-- Create the Publisher table
CREATE TABLE Publisher (
    Pub_ID INT PRIMARY KEY,
    Name VARCHAR(100),
    Phone VARCHAR(20),
    Email VARCHAR(100),
    Address VARCHAR(255),
    Book_ID INT,
    FOREIGN KEY (Book_ID) REFERENCES Book(BookID)
);
INSERT INTO Publisher (Pub_ID, Name, Phone, Email, Address, Book_ID) VALUES
(1, 'Penguin Random House', '123-111-2222', 'contact@penguinrandomhouse.com', '1745 Broadway, New York', 1),
(2, 'HarperCollins', '123-222-3333', 'info@harpercollins.com', '195 Broadway, New York', 2),
(3, 'Simon & Schuster', '123-333-4444', 'contact@simonandschuster.com', '1230 Avenue of the Americas, New York', 3),
(4, 'Macmillan', '123-444-5555', 'contact@macmillan.com', '120 Broadway, New York', 4),
(5, 'Hachette Livre', '123-555-6666', 'contact@hachette.com', '58 Rue de la Victoire, Paris', 5),
(6, 'Bloomsbury Publishing', '123-666-7777', 'contact@bloomsbury.com', '50 Bedford Square, London', 6),
(7, 'Scholastic', '123-777-8888', 'contact@scholastic.com', '557 Broadway, New York', 7),
(8, 'Oxford University Press', '123-888-9999', 'contact@oup.com', 'Great Clarendon Street, Oxford', 8),
(9, 'Cambridge University Press', '123-999-0000', 'contact@cambridge.org', 'University Printing House, Cambridge', 9),
(10, 'Pearson', '123-000-1111', 'contact@pearson.com', '80 Strand, London', 10);


-- 1. Total number of books borrowed by each member (Aggregate Function: COUNT)
SELECT m.Mem_ID, m.Fname, m.Lname, COUNT(b.BookID) AS Total_Books_Borrowed
FROM Member m
JOIN Member_Book mb ON m.Mem_ID = mb.Mem_ID
JOIN Book b ON mb.Book_ID = b.BookID
GROUP BY m.Mem_ID;
-- Relational Algebra: π Mem_ID, Fname, Lname, COUNT(BookID) (σ Mem_ID=Mem_ID ∧ Book_ID=BookID (Member ⨝ Member_Book ⨝ Book))

-- 2. Average Book Score per Author (Aggregate Function: AVG)
SELECT a.Name AS Author_Name, AVG(b.BScore) AS Avg_Book_Score
FROM Author a
JOIN Book b ON a.Author_ID = b.Author_ID
GROUP BY a.Name;
-- Relational Algebra: π Author_Name, AVG(BScore) (σ Author_ID=Author_ID (Author ⨝ Book))

-- 3. Members who borrowed more than 5 books (Condition: HAVING)
SELECT m.Mem_ID, m.Fname, m.Lname, COUNT(b.BookID) AS Total_Books_Borrowed
FROM Member m
JOIN Member_Book mb ON m.Mem_ID = mb.Mem_ID
JOIN Book b ON mb.Book_ID = b.BookID
GROUP BY m.Mem_ID
HAVING COUNT(b.BookID) > 5;
-- Relational Algebra: π Mem_ID, Fname, Lname, COUNT(BookID) (σ COUNT(BookID) > 5 (σ Mem_ID=Mem_ID ∧ Book_ID=BookID (Member ⨝ Member_Book ⨝ Book)))

-- 4. List of books and their categories (Inner Join)
SELECT b.Title, c.Type AS Category
FROM Book b
JOIN Book_Category bc ON b.BookID = bc.Book_ID
JOIN Category c ON bc.Cat_ID = c.Cat_ID;
-- Relational Algebra: π Title, Type (σ BookID=Book_ID ∧ Cat_ID=Cat_ID (Book ⨝ Book_Category ⨝ Category))

-- 5. Members who borrowed books of a specific category, e.g., "Fiction" (INNER JOIN + WHERE)
SELECT m.Mem_ID, m.Fname, m.Lname
FROM Member m
JOIN Member_Book mb ON m.Mem_ID = mb.Mem_ID
JOIN Book b ON mb.Book_ID = b.BookID
JOIN Book_Category bc ON b.BookID = bc.Book_ID
JOIN Category c ON bc.Cat_ID = c.Cat_ID
WHERE c.Type = 'Fiction';
-- Relational Algebra: π Mem_ID, Fname, Lname (σ Type='Fiction' (σ Mem_ID=Mem_ID ∧ Book_ID=Book_ID ∧ BookID=Book_ID (Member ⨝ Member_Book ⨝ Book ⨝ Book_Category ⨝ Category)))

-- 6. Books borrowed by a specific member, e.g., Mem_ID = 1 (INNER JOIN + WHERE)
SELECT b.Title, b.YearPub
FROM Book b
JOIN Member_Book mb ON b.BookID = mb.Book_ID
WHERE mb.Mem_ID = 1;
-- Relational Algebra: π Title, YearPub (σ Mem_ID=1 (σ BookID=Book_ID (Book ⨝ Member_Book)))

-- 7. Authors with more than 3 books published (Aggregate Function: COUNT + HAVING)
SELECT a.Name AS Author_Name, COUNT(b.BookID) AS Total_Books
FROM Author a
JOIN Book b ON a.Author_ID = b.Author_ID
GROUP BY a.Name
HAVING COUNT(b.BookID) > 3;
-- Relational Algebra: π Author_Name, COUNT(BookID) (σ COUNT(BookID) > 3 (σ Author_ID=Author_ID (Author ⨝ Book)))

-- 8. Books with available copies less than 5 (Condition: WHERE)
SELECT b.Title, b.CopiesAv
FROM Book b
WHERE b.CopiesAv < 5;
-- Relational Algebra: π Title, CopiesAv (σ CopiesAv < 5 (Book))

-- 9. Books published by a specific publisher, e.g., 'Penguin' (JOIN + WHERE)
SELECT b.Title, b.YearPub
FROM Book b
JOIN Publisher p ON b.Pub_ID = p.Pub_ID
WHERE p.Name = 'Penguin';
-- Relational Algebra: π Title, YearPub (σ Name='Penguin' (σ Pub_ID=Pub_ID (Book ⨝ Publisher)))

-- 10. Total number of transactions for each member (Aggregate Function: COUNT)
SELECT m.Mem_ID, m.Fname, m.Lname, COUNT(t.Trsc_ID) AS Total_Transactions
FROM Member m
JOIN Transaction t ON m.Mem_ID = t.Mem_ID
GROUP BY m.Mem_ID;
-- Relational Algebra: π Mem_ID, Fname, Lname, COUNT(Trsc_ID) (σ Mem_ID=Mem_ID ∧ Trsc_ID=Trsc_ID (Member ⨝ Transaction))

-- 11. List of all staff and their corresponding branch locations (Inner Join)
SELECT s.Name AS Staff_Name, b.Location AS Branch_Location
FROM Staff s
JOIN Staff_Branch sb ON s.Staff_ID = sb.Staff_ID
JOIN Branch b ON sb.Bran_ID = b.Bran_ID;
-- Relational Algebra: π Staff_Name, Branch_Location (σ Staff_ID=Staff_ID ∧ Bran_ID=Bran_ID (Staff ⨝ Staff_Branch ⨝ Branch))

-- 12. Members who borrowed books after a specific date (e.g., '2023-01-01') (Condition: WHERE)
SELECT m.Mem_ID, m.Fname, m.Lname
FROM Member m
JOIN Transaction t ON m.Mem_ID = t.Mem_ID
WHERE t.BorrowD > '2023-01-01';
-- Relational Algebra: π Mem_ID, Fname, Lname (σ BorrowD > '2023-01-01' (σ Mem_ID=Mem_ID ∧ Trsc_ID=Trsc_ID (Member ⨝ Transaction)))

-- 13. Books with their borrowing history (Subquery)
SELECT b.Title, (SELECT COUNT(*) FROM Transaction t WHERE t.Book_ID = b.BookID) AS Borrow_Count
FROM Book b;
-- Relational Algebra: π Title, COUNT(Trsc_ID) (σ BookID=Book_ID (Book ⨝ Transaction))

-- 14. Books with the highest score (Aggregate Function: MAX)
SELECT b.Title, b.BScore
FROM Book b
WHERE b.BScore = (SELECT MAX(BScore) FROM Book);
-- Relational Algebra: π Title, BScore (σ BScore = MAX(BScore) (Book))

-- 15. Books in 'Science' category but not in 'Fiction' category (Set Operator: EXCEPT)
SELECT b.BookID
FROM Book b
JOIN Book_Category bc ON b.BookID = bc.Book_ID
JOIN Category c ON bc.Cat_ID = c.Cat_ID
WHERE c.Type = 'Science'
EXCEPT
SELECT b.BookID
FROM Book b
JOIN Book_Category bc ON b.BookID = bc.Book_ID
JOIN Category c ON bc.Cat_ID = c.Cat_ID
WHERE c.Type = 'Fiction';
-- Relational Algebra: (π BookID (σ Type='Science' (σ BookID=Book_ID ∧ Cat_ID=Cat_ID (Book ⨝ Book_Category ⨝ Category)))) - (π BookID (σ Type='Fiction' (σ BookID=Book_ID ∧ Cat_ID=Cat_ID (Book ⨝ Book_Category ⨝ Category))))

-- 16. List of books and their authors (Inner Join)
SELECT b.Title, a.Name AS Author
FROM Book b
JOIN Author a ON b.Author_ID = a.Author_ID;
-- Relational Algebra: π Title, Author_Name (σ Author_ID=Author_ID (Book ⨝ Author))

-- 17. Members with overdue books (Condition: WHERE + Subquery)
SELECT m.Mem_ID, m.Fname, m.Lname
FROM Member m
JOIN Transaction t ON m.Mem_ID = t.Mem_ID
WHERE t.DueDate < CURDATE() AND t.ReturnD IS NULL;
-- Relational Algebra: π Mem_ID, Fname, Lname (σ DueDate < CURDATE() ∧ ReturnD IS NULL (σ Mem_ID=Mem_ID ∧ Trsc_ID=Trsc_ID (Member ⨝ Transaction)))

-- 18. List of all books published after 2010 (Condition: WHERE)
SELECT b.Title, b.YearPub
FROM Book b
WHERE b.YearPub > 2010;
-- Relational Algebra: π Title, YearPub (σ YearPub > 2010 (Book))

-- 19. Books borrowed by more than 3 members (Aggregate Function: COUNT + HAVING)
SELECT b.Title, COUNT(mb.Mem_ID) AS Borrow_Count
FROM Book b
JOIN Member_Book mb ON b.BookID = mb.Book_ID
GROUP BY b.Title
HAVING COUNT(mb.Mem_ID) > 3;
-- Relational Algebra: π Title, COUNT(Mem_ID) (σ COUNT(Mem_ID) > 3 (σ BookID=Book_ID (Book ⨝ Member_Book)))

-- 20. List of publishers and their books (Inner Join)
SELECT p.Name AS Publisher, b.Title AS Book_Title
FROM Publisher p
JOIN Book b ON p.Pub_ID = b.Pub_ID;
-- Relational Algebra: π Publisher, Book_Title (σ Pub_ID=Pub_ID (Publisher ⨝ Book))
