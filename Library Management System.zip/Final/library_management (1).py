import sqlite3
import tkinter as tk
from tkinter import simpledialog, messagebox, ttk
from datetime import datetime

# Database configuration
DB_NAME = 'library_management.db'

# Connect to the database
connection = sqlite3.connect(DB_NAME)
cursor = connection.cursor()

# Function to get all tables in the database
def get_tables():
    try:
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        return [table[0] for table in tables]
    except Exception as e:
        messagebox.showerror("Error", f"Error: {e}")
        return []

# Function to get rows for the selected table
def get_rows_for_table(table_name):
    try:
        cursor.execute(f"SELECT * FROM {table_name};")
        rows = cursor.fetchall()
        return rows
    except Exception as e:
        messagebox.showerror("Error", f"Error: {e}")
        return []

# Function to update the Treeview with values based on the selected table
def update_values_treeview(event=None):
    selected_table = table_combobox.get()  # Get the selected table
    rows = get_rows_for_table(selected_table)

    # Clear the Treeview before inserting new data
    for item in treeview.get_children():
        treeview.delete(item)

    if rows:
        cursor.execute(f"PRAGMA table_info({selected_table})")
        columns = cursor.fetchall()
        column_names = [col[1] for col in columns]  # Get column names dynamically
        treeview["columns"] = column_names  # Set the columns for the Treeview

        for col in column_names:
            treeview.heading(col, text=col)  # Set header text for each column
            treeview.column(col, anchor="center", width=100)  # Set column width and alignment

        # Insert rows into the Treeview
        for row in rows:
            treeview.insert("", tk.END, values=row)
    else:
        messagebox.showinfo("Info", "No data found in this table.")

# Function to add a new book
def add_book():
    keyword = simpledialog.askstring("Input", "Enter book keyword:")
    title = simpledialog.askstring("Input", "Enter book title:")
    year_pub = simpledialog.askstring("Input", "Enter year of publication:")
    copies_av = simpledialog.askinteger("Input", "Enter number of copies available:")
    bscore = simpledialog.askfloat("Input", "Enter popularity score:")
    author_id = simpledialog.askinteger("Input", "Enter author ID:")
    pub_id = simpledialog.askinteger("Input", "Enter publisher ID:")

    try:
        cursor.execute("""
            INSERT INTO Book (Keyword, Title, YearPub, CopiesAv, BScore, Author_ID, Pub_ID)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (keyword, title, year_pub, copies_av, bscore, author_id, pub_id))
        connection.commit()
        messagebox.showinfo("Success", "Book added successfully!")
        update_values_treeview()  # Update the treeview after adding a book
    except Exception as e:
        messagebox.showerror("Error", f"Error: {e}")

# Function to add a new member
def add_member():
    name = simpledialog.askstring("Input", "Enter member name:")
    address = simpledialog.askstring("Input", "Enter address:")
    phone = simpledialog.askstring("Input", "Enter phone:")
    email = simpledialog.askstring("Input", "Enter email:")
    membership_status = simpledialog.askstring("Input", "Enter membership status (Active/Inactive):")
    borrowing_history = simpledialog.askstring("Input", "Enter borrowing history (optional):")

    try:
        cursor.execute("""
            INSERT INTO Members (Name, Address, Phone, Email, Membership_Status, Borrowing_History)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (name, address, phone, email, membership_status, borrowing_history))
        connection.commit()
        messagebox.showinfo("Success", "Member added successfully!")
        update_values_treeview()  # Update the treeview after adding a member
    except Exception as e:
        messagebox.showerror("Error", f"Error: {e}")

# Function to borrow a book
def borrow_book():
    member_id = simpledialog.askinteger("Input", "Enter member ID:")
    book_id = simpledialog.askinteger("Input", "Enter book ID to borrow:")
    borrow_date = datetime.today().strftime('%Y-%m-%d')
    due_date = simpledialog.askstring("Input", "Enter due date (YYYY-MM-DD):")

    try:
        cursor.execute("SELECT CopiesAv FROM Book WHERE BookID = ?", (book_id,))
        copies_av = cursor.fetchone()[0]
        if copies_av <= 0:
            messagebox.showerror("Error", "No copies available for borrowing.")
            return

        # Update book copies and record borrowing
        cursor.execute("UPDATE Book SET CopiesAv = CopiesAv - 1 WHERE BookID = ?", (book_id,))
        cursor.execute("""
            INSERT INTO Transactions (Member_ID, Book_ID, Borrow_Date, Due_Date)
            VALUES (?, ?, ?, ?)
        """, (member_id, book_id, borrow_date, due_date))
        connection.commit()
        messagebox.showinfo("Success", "Book borrowed successfully!")
        update_values_treeview()  # Update the treeview after borrowing a book
    except Exception as e:
        messagebox.showerror("Error", f"Error: {e}")

# Function to return a borrowed book
def return_book():
    transaction_id = simpledialog.askinteger("Input", "Enter transaction ID to return the book:")
    return_date = datetime.today().strftime('%Y-%m-%d')

    try:
        cursor.execute("SELECT Book_ID FROM Transactions WHERE Transaction_ID = ?", (transaction_id,))
        book_id = cursor.fetchone()[0]

        # Update book copies and record return
        cursor.execute("UPDATE Book SET CopiesAv = CopiesAv + 1 WHERE BookID = ?", (book_id,))
        cursor.execute("UPDATE Transactions SET Return_Date = ? WHERE Transaction_ID = ?", (return_date, transaction_id))
        connection.commit()
        messagebox.showinfo("Success", "Book returned successfully!")
        update_values_treeview()  # Update the treeview after returning a book
    except Exception as e:
        messagebox.showerror("Error", f"Error: {e}")

# Function to delete a record
def delete_record():
    selected_table = table_combobox.get()
    selected_item = treeview.selection()
    if not selected_item:
        messagebox.showerror("Error", "No record selected.")
        return

    record = treeview.item(selected_item, 'values')
    cursor.execute(f"PRAGMA table_info({selected_table})")
    columns = cursor.fetchall()
    primary_key = columns[0][1]  # Assuming the first column is the primary key

    try:
        confirm = messagebox.askyesno("Confirm", f"Are you sure you want to delete the record: {record}?")
        if confirm:
            cursor.execute(f"DELETE FROM {selected_table} WHERE {primary_key} = ?", (record[0],))
            connection.commit()
            messagebox.showinfo("Success", "Record deleted successfully!")
            update_values_treeview()
    except Exception as e:
        messagebox.showerror("Error", f"Error: {e}")

# Function to edit a record
def edit_record():
    selected_table = table_combobox.get()
    selected_item = treeview.selection()
    if not selected_item:
        messagebox.showerror("Error", "No record selected.")
        return

    record = treeview.item(selected_item, 'values')
    cursor.execute(f"PRAGMA table_info({selected_table})")
    columns = cursor.fetchall()
    column_names = [col[1] for col in columns]

    updated_values = []
    for i, col in enumerate(column_names):
        new_value = simpledialog.askstring("Edit", f"Enter new value for {col} (current: {record[i]}):", initialvalue=record[i])
        updated_values.append(new_value)

    try:
        update_query = f"UPDATE {selected_table} SET " + ", ".join([f"{col} = ?" for col in column_names]) + f" WHERE {column_names[0]} = ?"
        cursor.execute(update_query, (*updated_values, record[0]))
        connection.commit()
        messagebox.showinfo("Success", "Record updated successfully!")
        update_values_treeview()
    except Exception as e:
        messagebox.showerror("Error", f"Error: {e}")

# Tkinter UI setup
root = tk.Tk()
root.title("Library Management System")

# Main frame
frame = ttk.Frame(root, padding="10")
frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

# Configure row/column weights for proper resizing
frame.columnconfigure(0, weight=1)
frame.rowconfigure(0, weight=1)

# Treeview to display rows (values) for the selected table
treeview = ttk.Treeview(frame, show="headings", height=15)
treeview.grid(row=0, column=0, columnspan=2, padx=10, pady=5, sticky="nsew")

# Add vertical scrollbar to Treeview
treeview_scroll_vertical = ttk.Scrollbar(frame, orient="vertical", command=treeview.yview)
treeview.configure(yscrollcommand=treeview_scroll_vertical.set)
treeview_scroll_vertical.grid(row=0, column=2, sticky="ns", padx=5, pady=5)

# Combobox to display tables (placed below the Treeview)
tables = get_tables()
table_combobox = ttk.Combobox(frame, values=tables, state="readonly")
table_combobox.grid(row=1, column=0, padx=10, pady=5, sticky="ew", columnspan=2)
table_combobox.bind("<<ComboboxSelected>>", update_values_treeview)

# Buttons frame for better alignment (placed below the combobox)
buttons_frame = ttk.Frame(frame)
buttons_frame.grid(row=2, column=0, columnspan=3, pady=10)

# Center the buttons within the buttons frame using a nested frame
center_frame = ttk.Frame(buttons_frame)
center_frame.grid(row=0, column=0, sticky="nsew", pady=10)

# Buttons for actions
add_book_button = ttk.Button(center_frame, text="Add Book", command=add_book)
add_book_button.grid(row=0, column=0, padx=5, pady=5)

add_member_button = ttk.Button(center_frame, text="Add Member", command=add_member)
add_member_button.grid(row=0, column=1, padx=5, pady=5)

borrow_book_button = ttk.Button(center_frame, text="Borrow Book", command=borrow_book)
borrow_book_button.grid(row=0, column=2, padx=5, pady=5)

return_book_button = ttk.Button(center_frame, text="Return Book", command=return_book)
return_book_button.grid(row=0, column=3, padx=5, pady=5)

delete_record_button = ttk.Button(center_frame, text="Delete Record", command=delete_record)
delete_record_button.grid(row=1, column=0, padx=5, pady=5)

edit_record_button = ttk.Button(center_frame, text="Edit Record", command=edit_record)
edit_record_button.grid(row=1, column=1, padx=5, pady=5)

# Adjust spacing for proper alignment
for child in center_frame.winfo_children():
    child.grid_configure(sticky="ew")

# Add weight to the buttons_frame for centering
buttons_frame.columnconfigure(0, weight=1)
buttons_frame.rowconfigure(0, weight=1)

# Set the default table view on startup
if tables:
    update_values_treeview(None)

root.mainloop()

# Close the database connection on exit
connection.close()
